// lwm2m_objects_manager.cpp
#include "lwm2m_objects_manager.h"
#include "config.h"

// Instância global
LWM2MObjectsManager objectsManager;

LWM2MObjectsManager::LWM2MObjectsManager() {
    // Criar sensores de temperatura
    temperature[0] = new LWM2MTemperature(DHT_PIN_0, 0);
    temperature[1] = new LWM2MTemperature(DHT_PIN_1, 1);
    
    // Criar sensores de umidade (mesmos pinos dos DHT)
    humidity[0] = new LWM2MHumidity(DHT_PIN_0, 0);
    humidity[1] = new LWM2MHumidity(DHT_PIN_1, 1);
}

LWM2MObjectsManager::~LWM2MObjectsManager() {
    delete temperature[0];
    delete temperature[1];
    delete humidity[0];
    delete humidity[1];
}

void LWM2MObjectsManager::begin() {
    Serial.println("\n🔧 Inicializando objetos IPSO...");
    
    // Inicializar sensores de temperatura
    temperature[0]->begin();
    temperature[1]->begin();
    
    // Inicializar sensores de umidade
    humidity[0]->begin();
    humidity[1]->begin();
    
    Serial.println("✅ Objetos IPSO prontos!");
    
    // Mostrar status inicial
    printStatus();
}

void LWM2MObjectsManager::update() {
    // Atualizar sensores
    temperature[0]->update();
    temperature[1]->update();
    humidity[0]->update();
    humidity[1]->update();
}

bool LWM2MObjectsManager::processRead(uint16_t objectId, uint16_t instanceId, 
                                      uint16_t resourceId, String& value) {
    switch (objectId) {
        case 3303: // Temperature
            if (instanceId < 2) {
                switch (resourceId) {
                    case 5700: // Sensor Value
                        value = String(temperature[instanceId]->getValue(), 1);
                        return true;
                    case 5701: // Units
                        value = temperature[instanceId]->getUnits();
                        return true;
                    case 5601: // Min Value
                        value = String(temperature[instanceId]->getMinValue(), 1);
                        return true;
                    case 5602: // Max Value
                        value = String(temperature[instanceId]->getMaxValue(), 1);
                        return true;
                }
            }
            break;
            
        case 3304: // Humidity
            if (instanceId < 2) {
                switch (resourceId) {
                    case 5700: // Sensor Value
                        value = String(humidity[instanceId]->getValue(), 1);
                        return true;
                    case 5701: // Units
                        value = humidity[instanceId]->getUnits();
                        return true;
                    case 5601: // Min Value
                        value = String(humidity[instanceId]->getMinValue(), 1);
                        return true;
                    case 5602: // Max Value
                        value = String(humidity[instanceId]->getMaxValue(), 1);
                        return true;
                }
            }
            break;
            
        case 3311: // Light Control
            if (instanceId < 3) {
                switch (resourceId) {
                    case 5850: // On/Off
                        value = light_get_onoff(instanceId) ? "1" : "0";
                        return true;
                    case 5851: // Dimmer
                        value = String(light_get_dimmer(instanceId));
                        return true;
                    case 5706: // Colour
                        value = light_get_colour(instanceId);
                        return true;
                }
            }
            break;
    }
    
    return false;
}

bool LWM2MObjectsManager::processWrite(uint16_t objectId, uint16_t instanceId, 
                                       uint16_t resourceId, const String& value) {
    switch (objectId) {
        case 3311: // Light Control
            if (instanceId < 3) {
                switch (resourceId) {
                    case 5850: // On/Off
                        light_set_onoff(instanceId, value == "1");
                        Serial.printf("💡 LED %d: %s\n", instanceId, 
                                    value == "1" ? "ON" : "OFF");
                        return true;
                    case 5851: // Dimmer
                        {
                            int dimValue = value.toInt();
                            if (dimValue >= 0 && dimValue <= 100) {
                                light_set_dimmer(instanceId, dimValue);
                                Serial.printf("🔆 LED %d dimmer: %d%%\n", 
                                            instanceId, dimValue);
                                return true;
                            }
                        }
                        break;
                }
            }
            break;
    }
    
    return false;
}

bool LWM2MObjectsManager::processExecute(uint16_t objectId, uint16_t instanceId, 
                                         uint16_t resourceId) {
    switch (objectId) {
        case 3303: // Temperature
            if (instanceId < 2 && resourceId == 5605) {
                temperature[instanceId]->resetMinMax();
                return true;
            }
            break;
            
        case 3304: // Humidity
            if (instanceId < 2 && resourceId == 5605) {
                humidity[instanceId]->resetMinMax();
                return true;
            }
            break;
    }
    
    return false;
}

void LWM2MObjectsManager::printStatus() {
    Serial.println("\n📊 === STATUS DOS OBJETOS IPSO ===");
    
    // Status dos LEDs
    Serial.println("💡 Light Control (3311):");
    const char* colors[] = {"Vermelho", "Azul", "Amarelo"};
    for (int i = 0; i < 3; i++) {
        Serial.printf("  [%d] %s: %s, Dimmer: %d%%\n", 
                      i, colors[i],
                      light_get_onoff(i) ? "ON" : "OFF",
                      light_get_dimmer(i));
    }
    
    // Status da temperatura
    Serial.println("🌡️ Temperature (3303):");
    for (int i = 0; i < 2; i++) {
        if (temperature[i]->isValid()) {
            Serial.printf("  [%d] %.1f°C (min: %.1f, max: %.1f)\n",
                          i, temperature[i]->getValue(),
                          temperature[i]->getMinValue(),
                          temperature[i]->getMaxValue());
        } else {
            Serial.printf("  [%d] Aguardando leitura...\n", i);
        }
    }
    
    // Status da umidade
    Serial.println("💧 Humidity (3304):");
    for (int i = 0; i < 2; i++) {
        if (humidity[i]->isValid()) {
            Serial.printf("  [%d] %.1f%% (min: %.1f, max: %.1f)\n",
                          i, humidity[i]->getValue(),
                          humidity[i]->getMinValue(),
                          humidity[i]->getMaxValue());
        } else {
            Serial.printf("  [%d] Aguardando leitura...\n", i);
        }
    }
    
    Serial.println("==================================\n");
}